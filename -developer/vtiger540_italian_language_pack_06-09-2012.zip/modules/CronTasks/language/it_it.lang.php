<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
	'LBL_ACTIVE' => 'Attivo',
	'LBL_INACTIVE' => 'Inattivo',
	'LBL_STATUS' => 'Stato',
	'LBL_SCHEDULER' => 'Programmazione',
	'LBL_SETTINGS' => 'Impostazioni',
	'LBL_FREQUENCY'=> 'Frequenza',
	'LBL_HOURMIN' => '(H:M)',
	'LAST_START'=>'Avvio Ultima Scansione',
	'LAST_END'=>'Termine Ultima Scansione',
	'LBL_SEQUENCE'=>'Sequenza',
	'LBL_TOOLS' =>'Strumenti',
	'LBL_DAYS'=>'Giorni',
	'LBL_HOURS'=>'Ore',
	'LBL_MINS'=>'Minuti',
	'LBL_RUNNING'=>'In esecuzione',
	'LBL_MINIMUM_FREQUENCY'=>'La frequenza di ciascun CronJob e impostata su valori maggiori di',
	'LBL_SECONDS'=>'secondi fa',
	'LBL_MINUTES'=>'minuti fa',
	'LBL_HOURS'=>'ore fa',
	'LBL_DAYS'=>'giorni fa',
	'LBL_MONTHS'=>'mesi fa',
	'LBL_YEARS'=>'anni fa',
);
?>