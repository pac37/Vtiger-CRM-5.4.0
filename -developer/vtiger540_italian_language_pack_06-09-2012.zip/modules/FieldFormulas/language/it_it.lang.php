<?php
/*+*******************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ******************************************************************************/
$mod_strings = Array (
'FieldFormulas' => 'Campi Formula',
'LBL_FIELDFORMULAS' => 'Campi Formula',
'LBL_FIELDFORMULAS_DESCRIPTION' => 'Aggiungi equazioni personalizzate ai campi personalizzati',
'LBL_FIELDS' => 'Campi',
'LBL_FUNCTIONS' => 'Funzioni',
'LBL_FIELD' => 'Campo',
'LBL_EXPRESSION' => 'Espressione',
'LBL_SETTINGS' => 'Impostazioni',
'LBL_NEW_FIELD_EXPRESSION_BUTTON' => 'Nuovo Campo Espressione',
'LBL_EDIT_EXPRESSION' => 'Modifica Espressione',
'LBL_MODULE_INFO' => 'Forumle definite per ',
'NEED_TO_ADD_A' =>'&Egrave; necessario aggiungere un campo stringa o intero ',
'LBL_CUSTOM_FIELD' =>'Campo personalizzato',
'LBL_CHECKING'=>'Verifica...',
'LBL_SELECT_ONE_DOTDOTDOT'=>'Seleziona Uno...',
'LBL_TARGET_FIELD'=>'Campo Obbiettivo',
'LBL_DELETE_EXPRESSION_CONFIRM'=>'Sei sicuro di cancellare l\'espressione?',
'LBL_EXAMPLES'=>'Esempi',
'LBL_USE_FIELD_VALUE_DASHDASH'=>'-- Usa Valore Campo --',
'LBL_USE_FUNCTION_DASHDASH'=>'-- Usa Funzione --',
);

?>